@echo off
echo ===================================================
echo BigLineconnect Service Setup
echo ===================================================
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [ERROR] Lutfen bu dosyaya sag tiklayip "Yonetici Olarak Calistir" secenegini secin!
    echo.
    pause
    exit /b
)

echo [1/4] Eski servisler durduruluyor ve siliniyor...
sc stop BigLineconnectSvc >nul 2>&1
timeout /t 2 /nobreak >nul
sc delete BigLineconnectSvc >nul 2>&1
timeout /t 2 /nobreak >nul
sc stop BigLineconnect >nul 2>&1
timeout /t 2 /nobreak >nul
sc delete BigLineconnect >nul 2>&1
timeout /t 2 /nobreak >nul

echo [2/4] Calisan uygulamalar kapatiliyor...
taskkill /f /im BigLineconnect.exe >nul 2>&1
taskkill /f /im BigLineconnect_modern.exe >nul 2>&1
taskkill /f /im BigLineconnect_v13.exe >nul 2>&1
timeout /t 1 /nobreak >nul

echo [2.5/4] Ayarlar dizini izinleri ayarlaniyor...
if not exist "C:\ProgramData\BigLineconnect" mkdir "C:\ProgramData\BigLineconnect"
icacls "C:\ProgramData\BigLineconnect" /grant *S-1-1-0:(OI)(CI)F /T >nul 2>&1

echo [3/4] Yeni servis kuruluyor (BigLineconnectSvc -> BigLineconnect.exe)...
sc create BigLineconnectSvc binPath= "\"%~dp0BigLineconnect.exe\" --service" start= auto
sc description BigLineconnectSvc "BigLineconnect Uzaktan Kontrol Servisi"
sc failure BigLineconnectSvc reset= 86400 actions= restart/60000/restart/60000/restart/60000

echo [4/4] Servis baslatiliyor...
sc start BigLineconnectSvc
timeout /t 2 /nobreak >nul

echo.
echo ===================================================
echo BASARILI! BigLineconnect Servisi kuruldu ve baslatildi.
echo ===================================================
echo.
pause
